package com.bike.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="manager_login")
public class Manager_Login {
	@Id
	private int manager_id;
	
	@Column(name="manager_name")
	private String manager_name;
	
	@Column(name="password")
	private String password;

	public int getManager_id() {
		return manager_id;
	}

	public String getManager_name() {
		return manager_name;
	}

	public String getPassword() {
		return password;
	}

	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}

	public void setManager_name(String manager_name) {
		this.manager_name = manager_name;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
