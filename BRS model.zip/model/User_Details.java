package com.bike.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_details")
public class User_Details {
	@Id
	private int user_id;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@Column(name="email")
	private String email;
	
	@Column(name="mobile")
	private long mobile;
	
	@Column(name="licence")
	private String licence;	
	
	@Column(name="address")
	private String address;

	public int getUser_id() {
		return user_id;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public String getEmail() {
		return email;
	}

	public long getMobile() {
		return mobile;
	}

	public String getLicence() {
		return licence;
	}

	public String getAddress() {
		return address;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
