package com.bike.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="shop_details")
public class Shop_Details {
	@Id
	private String name;

	@Column(name="email")
	private String email;
	
	@Column(name="mobile")
	private long mobile;	
	
	@Column(name="address")
	private String address;

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public long getMobile() {
		return mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
