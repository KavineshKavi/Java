package com.bike.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bike")
public class Bike {
	@Id
	private String vehicle_no;
	
	@Column(name="name")
	private String name;
	
	@Column(name="model")
	private String model;
	
	@Column(name="cc")
	private int cc;
	
	@Column(name="availability")
	private int availability;
	
	@Column(name="rent")
	private float rent;

	public String getVehicle_no() {
		return vehicle_no;
	}

	public String getName() {
		return name;
	}

	public String getModel() {
		return model;
	}

	public Integer getCc() {
		return cc;
	}

	public Integer getAvailability() {
		return availability;
	}

	public Float getRent() {
		return rent;
	}

	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setCc(int cc) {
		this.cc = cc;
	}

	public void setAvailability(int availability) {
		this.availability = availability;
	}

	public void setRent(float rent) {
		this.rent = rent;
	}

	
}
