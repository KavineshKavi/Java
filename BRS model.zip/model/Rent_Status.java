package com.bike.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="rent_status")
public class Rent_Status {
	@Id
	private int bill_id;
	
	@Column(name="user_id")
	private int user_id;
	
	@Column(name="vehicle_no")
	private String vehicle_no;

	@Column(name="check_in")
	private String check_in;

	@Column(name="check_out")
	private String check_out;

	@Column(name="approval")
	private boolean approval;

	@Column(name="manager_id")
	private int manager_id;

	public int getBill_id() {
		return bill_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public String getVehicle_no() {
		return vehicle_no;
	}

	public String getCheck_in() {
		return check_in;
	}

	public String getCheck_out() {
		return check_out;
	}

	public boolean isApproval() {
		return approval;
	}

	public int getManager_id() {
		return manager_id;
	}

	public void setBill_id(int bill_id) {
		this.bill_id = bill_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}

	public void setCheck_in(String check_in) {
		this.check_in = check_in;
	}

	public void setCheck_out(String check_out) {
		this.check_out = check_out;
	}

	public void setApproval(boolean approval) {
		this.approval = approval;
	}

	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	
	
}
